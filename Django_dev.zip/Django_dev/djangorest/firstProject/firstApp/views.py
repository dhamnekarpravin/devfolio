from django.shortcuts import render
from django.http import JsonResponse


# Create your views here.
def employees(request):
    emp = {
        'id':1,
        'name':'Pravin',
        'salary':29000
    }
    return JsonResponse(emp)

