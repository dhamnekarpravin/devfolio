import matplotlib.pyplot as plt
import geopandas as gpd
from shapely.geometry import Polygon

# Create India map using approximate coordinates
india_coords = [
    [68.7, 37.1],  # Northwest
    [77.8, 35.5],  # North
    [88.1, 27.9],  # Northeast
    [97.4, 28.6],  # Far Northeast
    [95.2, 26.5],  # East
    [92.1, 21.9],  # Southeast
    [88.9, 22.0],  # East Central
    [86.0, 21.5],  # Central East
    [82.2, 19.5],  # Central
    [78.5, 18.0],  # Central West
    [74.4, 18.5],  # West
    [71.8, 23.0],  # Northwest
    [68.7, 37.1],  # Close the polygon
]

# Create polygon
india_polygon = Polygon(india_coords)

# Create GeoDataFrame
gdf = gpd.GeoDataFrame(geometry=[india_polygon], crs="EPSG:4326")

# Plot
fig, ax = plt.subplots(figsize=(10, 8))
gdf.plot(ax=ax, color='orange', edgecolor='black', linewidth=2)
ax.set_title('Map of India', fontsize=16, fontweight='bold')
ax.set_xlabel('Longitude', fontsize=12)
ax.set_ylabel('Latitude', fontsize=12)
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('india_map.png', dpi=300, bbox_inches='tight')
print("India map saved as 'india_map.png'")
plt.show()
