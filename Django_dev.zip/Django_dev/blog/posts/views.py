from django.shortcuts import render
from django.http import HttpResponse, HttpResponseNotFound, HttpResponseRedirect
from django.urls import reverse


# Create your views here.

posts = [
    {
        "id":1,
        "title":"first post",
        "content":"this is the first post content"
    },
     {
        "id":2,
        "title":"second post",
        "content":"this is the second post content"
    },
     {
        "id":3,
        "title":"third post",
        "content":"this is the third post content"
    },
     {
        "id":4,
        "title":"fourth post",
        "content":"this is the fourth post content"
    }


]

def home(request):
    # print(reverse("home"))
    html=""
    for post in posts:
        html += f'''
        <div>
        <a href="/post/{post["id"]}">
        <h1>{post["id"]} - {post["title"]}</h1></a>
        <p>{post["content"]}</p>

        </div>
        '''
    return HttpResponse(html)


def post(request,id):
    # print(type(id))
    valid_id = False
    for post in posts:
        if post["id"]==id:
            post_dict = post
            valid_id = True
            break

    if valid_id:    
    
        html = f'''

        <div>
        <h1>{post["title"]}</h1>

        <p>{post["content"]}</p>


        </div>

        '''
        
        return HttpResponse(html)
    
    else:
        return HttpResponseNotFound("<h1> 404 - Post not found 😒😒</h1>")


def google(request,id):
    return HttpResponseRedirect(f"/post/{id}/")
    


